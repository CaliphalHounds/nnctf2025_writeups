# Mod para GTA San Andreas - ¡Navajas para todos! by AELOOP

Un mod CLEO que añade funcionalidad de lanzamiento y obtención de cuchillos al juego GTA San Andreas.

<p align="center">
  <img src="intro.gif" alt="intro" />
</p>

## Descripción

Este mod permite al jugador lanzar cuchillos como proyectiles en el juego, añadiendo una nueva mecánica de combate. El sistema incluye activación por comando, obtención de armas y lanzamiento con física realista.

## Características

- **Activación/Desactivación**: Sistema de fijación para el modo cuchillos.
- **Obtención de cuchillos**: Comando rápido para obtener el arma.
- **Lanzamiento**: Mecánica de lanzamiento con física y colisiones.
- **Efectos visuales**: Animaciones y feedback visual.
- **Detección de impactos**: Sistema de colisión con NPCs y entorno.

## Uso

### Comandos

| Ejecucción | Orden | Función |
|---------|----------|---------|
| 1º      | `NAVAJA` | Activa/desactiva el modo cuchillos |
| 2º      |  `k`     | Obtiene un cuchillo (solo cuando el modo está activo) |

### Controles

- **TAB**: Lanza el cuchillo cuando tienes uno equipado.
- El jugador debe estar:
  - Fuera de vehículos
  - En tierra (no en el aire o agua)
  - Con un cuchillo equipado*

## Mecánicas del Juego

### Sistema de Activación
- El mod incluye un sistema que permite activar/desactivar la funcionalidad.
- Muestra mensajes en pantalla confirmando el estado actual.

### Obtención de Cuchillos
- Al usar el comando `k`, el jugador recibe:
  - Un cuchillo con 60 unidades de munición.
  - El arma se equipa automáticamente.
  - Mensaje de confirmación en pantalla.

### Lanzamiento
- **Animación**: Reproduce la animación de lanzar granada.
- **Física**: El cuchillo sigue una trayectoria realista basada en la dirección del jugador.
- **Velocidad**: 80 unidades en dirección horizontal, altura adicional de 3 unidades.
- **Colisión**: Detecta impactos con objetos y NPCs
- **Alcance**: Máximo de 50 unidades de distancia

### Sistema de Impacto
- **NPCs**: Los cuchillos pueden eliminar NPCs al impactar.
- **Entorno**: Detecta colisiones con el terreno y objetos.
- **Pickup**: Tras el impacto, se crea un pickup del cuchillo en el suelo.

## Archivos del Mod

### `activador.cs`
Maneja el sistema de activación/desactivación del mod mediante el comando "NAVAJA".

### `Cuchillo.cs`
Controla la obtención de cuchillos al pulsar la tecla "k" y proporciona feedback al jugador con un cuadro de texto.

### `lanzamiento.cs`
Implementa la mecánica principal de lanzamiento, incluyendo:
- Detección de condiciones.
- Creación de objetos (cuchillo visible + colisión invisible).
- Física de proyectil.
- Sistema de impacto.
- Limpieza de objetos.

## Requisitos Técnicos

- **CLEO Library 4.4.4 o superior**: Requerido para ejecutar scripts `.cs`.
- **GTA San Andreas**: Versión compatible con CLEO.
- **Modelos**: Utiliza modelos existentes del juego (#KNIFECUR, #BBALL_COL).
- **Animaciones**: Usa animaciones de la categoría "GRENADE".

## Notas Técnicas

### Objetos Utilizados
- `#KNIFECUR`: Modelo visual del cuchillo.
- `#BBALL_COL`: Objeto de colisión invisible (esfera de baloncesto).

### Variables de Control
- `$NAVAJA_FLAG`: Controla el estado activo/inactivo del mod.
- Variables locales para coordenadas, objetos y referencias de personajes.

### Gestión de Memoria
El mod incluye limpieza automática de recursos:
- Eliminación de objetos tras impacto.
- Liberación de modelos no utilizados.
- Limpieza de animaciones cargadas.

## Troubleshooting

- **El mod no responde**: Verifica que CLEO esté correctamente instalado
- **Comandos no funcionan**: Asegúrate de escribir los comandos exactamente como se indica en el apartado `uso`
- **Crashes**: Comprueba que no hay conflictos con otros mods CLEO
- **Animaciones incorrectas**: Verifica la integridad de los archivos del juego

## Compatibilidad

- Compatible con la mayoría de mods que no modifiquen el sistema de armas
- Puede requerir ajustes si se usan otros mods de combate
- Testear compatibilidad con mods que modifiquen animaciones

## Instalación

Tutorial de instalación en el foro [http://challs.caliphalhounds.com:11920/viewtopic.php?t=4](http://challs.caliphalhounds.com:11920/viewtopic.php?t=4) + corrección posibles bugs.



//TODO: Entregar a Weber una vez finalizado.